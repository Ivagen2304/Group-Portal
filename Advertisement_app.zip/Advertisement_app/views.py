
from django.shortcuts import render
from django.views.generic import ListView
from .models import *

class AdvertisementListView(ListView):
    model = Advertisement
    template_name = 'advertisement_list.html'  # Виправлено
    context_object_name = 'advertisements'  # Виправлено
