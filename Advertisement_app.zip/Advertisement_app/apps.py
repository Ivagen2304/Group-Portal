from django.apps import AppConfig


class AdvertisementAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Advertisement_app'
