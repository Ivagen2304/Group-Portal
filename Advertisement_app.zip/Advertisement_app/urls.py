from .views import AdvertisementListView
from django.urls import path, include

urlpatterns =[
path('', AdvertisementListView.as_view(), name='advertisement_list')]